
// AOS.init({
  // duration: 850,
// })

let sum = 0

let gem = sessionStorage.setItem("test",23)

//Brug parseInt for at lægge tal sammen
//Få billede med i indkøbskurven
Pizza.addEventListener('click',
  function(){
    bestillinger.innerHTML += Pizza.innerHTML
    //bestillinger.innerHTML += parseInt(sessionStorage.getItem("test")) + parseInt(sessionStorage.getItem("test"))
    sum = sum + 89
    ialt.innerHTML= sum;

  })

//Få kun teksten over i indkøbskurven
  Burger.addEventListener('click',
    function(){
      bestillinger.innerHTML += Burger.innerHTML
      sum = sum + 79
      ialt.innerHTML= sum;

    })

Pasta.addEventListener('click',
    function(){
      bestillinger.innerHTML += Pasta.innerHTML //Hvis bare tekst uden billede gør sådan: "<p>Pasta Kødsovs</p>"
      sum = sum + 75
      ialt.innerHTML= sum;
    })

    //betal knap
  betal.addEventListener('click', function(){
    localStorage.setItem("liste",bestillinger.innerHTML)
  })
